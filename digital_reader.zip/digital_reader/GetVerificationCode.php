<?php

include "connection.php";


if($_SERVER['REQUEST_METHOD']=='POST'){

   $email = $_POST['email'];
   

}

if($_SERVER['REQUEST_METHOD']=='GET'){

    $email = $_GET['email'];
   
   
}

   
 $sql_select="SELECT * FROM `user_verification`  WHERE  `email`= '$email' AND `disable_flag`= '0'";  
$result_select=mysqli_query($conn,$sql_select);

$result_count=mysqli_num_rows($result_select);

if($result_count>0)
{
    while($row=mysqli_fetch_array($result_select))
        {



            $activation_code=$row['activation_code'];

            // $Details=array( "activation_code" =>$activation_code);
     


        }



        $result =array();
       $result["msg"] ="success";
       $result["response"] =$activation_code;
       echo json_encode($result);

   
}else
    {
        $result =array();
       $result["msg"] ="failure";
       $result["response"] ="Something wents Wrong!";
       echo json_encode($result);
    }

?>
