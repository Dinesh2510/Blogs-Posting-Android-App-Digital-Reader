
<?php
        include 'connection.php';

        $count = null;



        if($_SERVER['REQUEST_METHOD']=='POST'){


        $count= $_POST['count'];
        $post_id= $_POST['post_id'];
        $user_id =$_POST['user_id'];

        }

        if($_SERVER['REQUEST_METHOD']=='GET'){


        $count= $_GET['count'];
        $post_id= $_GET['post_id'];
        $user_id =$_GET['user_id'];

        }

        $SelectSql = "SELECT * FROM `dr_posts` WHERE `post_id`='$post_id'";
        $resultSel=mysqli_query($conn,$SelectSql);
        while($row=mysqli_fetch_assoc($resultSel)) {

        $post_like=$row['post_like'];
        }


        $count =$count + $post_like;



        $sql="UPDATE dr_posts SET`post_like`= '$count' WHERE `post_id`='$post_id' ";
        $result=mysqli_query($conn,$sql);

        if($result)
        {


        $SelectlikeSql = "SELECT * FROM `dr_likepost` WHERE `post_id`='$post_id' AND `user_id` ='$user_id'";
        $result_select_like=mysqli_query($conn,$SelectlikeSql);

// echo mysqli_num_rows($result_select_like);
// var_dump( mysqli_num_rows($result_select_like));
// die();
//if post and user_id is already available than update else insert
        if(mysqli_num_rows($result_select_like) > 0){
        $sql="UPDATE dr_likepost SET`like_count`= '$count' WHERE `post_id`='$post_id' AND `user_id` ='$user_id' ";
        $result=mysqli_query($conn,$sql);
        $response = array("response"=> "success");
        echo json_encode($response);
        }else{
        $InsertSql = "INSERT INTO `dr_likepost` ( `user_id`, `post_id`, `like_count`) VALUES ( '$user_id', '$post_id', '$count')";
        $result_select=mysqli_query($conn,$InsertSql);
        $response = array("response"=> "success");
        echo json_encode($response);
        }

        }
        else
        {
        $response = array("response"=>"failure");
        echo json_encode($response);
        }

        ?>