<?php
include 'connection.php';
$first_name= null;
$last_name= null;
$email = null; 
$password = null; 

if($_SERVER['REQUEST_METHOD']=='POST'){
    
$first_name = $_POST['first_name'];
$last_name= $_POST['last_name'];
$email= $_POST['email'];
$password= $_POST['password'];
$fcm_id= $_POST['fcm_id'];
$version_code= $_POST['version_code'];
$version_name= $_POST['version_name'];

}

if($_SERVER['REQUEST_METHOD']=='GET'){
$first_name = $_GET['first_name'];
$last_name= $_GET['last_name'];
$email= $_GET['email'];
$password= $_GET['password'];
$fcm_id= $_GET['fcm_id'];
$version_code= $_GET['version_code'];
$version_name= $_GET['version_name'];
       
}

$sql_check_email ="SELECT * FROM `dr_users` WHERE `email`='$email'";
$result_chk_email=mysqli_query($conn,$sql_check_email);
if($result_chk_email->num_rows >= 1) {
    $email_result= true;  
}else{  
    $email_result= false;
}
if($email_result == false) {
$sql= "INSERT INTO `dr_users`( `first_name`, `last_name`, `email`, `password`,`fcm_id`,`version_code`,`version_name`) VALUES (
		'$first_name', 
        '$last_name', 
        '$email', 
        '$password',
        '$fcm_id',
        '$version_code',
        '$version_name' )";
$result=mysqli_query($conn,$sql);
if($result)
{
    $result =array();
    $result["msg"] = true;
    $result["response"] ="success";
    echo json_encode($result);
    }else
    {
    $result =array();
    $result["msg"] = false;
    $result["response"] ="failure";
    echo json_encode($result);
    }
}else{
    $result =array();
    $result["msg"] = "Email is already Exist.";
    $result["response"] ="failure";
    echo json_encode($result);
}




?>
