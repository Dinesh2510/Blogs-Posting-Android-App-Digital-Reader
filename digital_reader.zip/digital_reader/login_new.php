<?php

include "connection.php";

$name = null;
$email=null;
$phone=null;
$address=null;
$password=null;
$user_id=null;
$email_result=null;
$password_result= null;

if($_SERVER['REQUEST_METHOD']=='POST')
{
$email=$_POST['email'];
$password=$_POST['password'];
$version_code= $_POST['version_code'];
$version_name= $_POST['version_name'];
}


if($_SERVER['REQUEST_METHOD']=='GET')
{
   
$email=$_GET['email'];
$password=$_GET['password'];
$version_code= $_GET['version_code'];
$version_name= $_GET['version_name'];
}

$sql_check_email ="SELECT * FROM `dr_users` WHERE `email`='$email'";
$result_chk_email=mysqli_query($conn,$sql_check_email);
if($result_chk_email->num_rows >= 1) {
	$email_result= true;  
}else{	
	$email_result= false;
}

$sql_check_password ="SELECT * FROM `dr_users` WHERE `email`='$email' AND `password`= '$password'";
$result_chk_password=mysqli_query($conn,$sql_check_password);
if ($result_chk_password-> num_rows >= 1) {
	$password_result = true;
}else{
	$password_result=false;
}

$sql_check_active ="SELECT * FROM `dr_users` WHERE `email`='$email' AND `active_flag`= '0'";
$result_chk_active=mysqli_query($conn,$sql_check_active);
if ($result_chk_active-> num_rows >= 1) {
	$active_result = true;
}else{
	$active_result=false;
}
if ($email_result == false) {
	$result =array();
    $result["msg"] ="Email is not exist so please register";
    $result["response"] ="failure";
    echo json_encode($result);
	}else if($active_result == false){
    $result =array();
    $result["msg"] ="Email is Not Verified!";
    $result["response"] ="failure";
    echo json_encode($result);
    }elseif ($email_result == true && $password_result == false) {
	$result =array();
    $result["msg"] ="email and Password not match!";
    $result["response"] ="failure";
    echo json_encode($result);
	}elseif ( $email_result && $password_result) {
    $sql_select="SELECT * FROM `dr_users` WHERE `email`='$email' AND `password`= '$password'  AND `disable_flag`= '0' AND `active_flag`= '0'";
    $result_select=mysqli_query($conn,$sql_select);
    $result_count=mysqli_num_rows($result_select);
    if($result_count>0)
    {
while($row=mysqli_fetch_array($result_select))
        {
        $first_name=$row['first_name'];
        $last_name=$row['last_name'];
        $password=$row['password']; 
        $email=$row['email']; 
        $user_id=$row['user_id'];
        $password=$row['password'];
        $user_premiumflag=$row['user_premiumflag'];
        // $name = $first_name." ".$last_name;
        $UserDetails=array(
                            "user_id" =>$user_id,
                            "first_name" =>$first_name,
                            "last_name" =>$last_name,
                            "email" => $email,
                            "password" => $password,
                            "userpremiumflag" =>$user_premiumflag
                            );
            
        }
   
}
if ($result_count) {
 $sql_update ="UPDATE `dr_users` SET `version_code` = '$version_code', `version_name` = '$version_name' WHERE `dr_users`.`user_id` = $user_id";  
 $result_update=mysqli_query($conn,$sql_update);
    $result =array();
    $result["msg"] ="success";
    $result["response"] =$UserDetails;
    echo json_encode($result);
}
}
else
{
    $result =array();
    $result["msg"] = false;
    $result["response"] ="failure";
    echo json_encode($result);
}

   


?>