<?php

include "connection.php";

if($_SERVER['REQUEST_METHOD']=='POST'){

	$post_id = $_POST['post_id'];
	

}

if($_SERVER['REQUEST_METHOD']=='GET'){


   $post_id = $_GET['post_id'];
   
}

   
 $sql_select="SELECT * FROM `dr_comments`  WHERE  `disable_flag`= '0' AND `post_id` = '$post_id' ";  
$result_select=mysqli_query($conn,$sql_select);

$result_count=mysqli_num_rows($result_select);

if($result_count>0)
{
    while($row=mysqli_fetch_array($result_select))
        {

            $comment_id=$row['comment_id'];
            $user_id=$row['user_id'];
            $post_id=$row['post_id'];
            $post_comment=$row['post_comment'];
            $post_date=$row['comment_date'];
        
    $new_date = date("d-F-Y",strtotime($post_date));
    
         $SELECT_USER = "SELECT * FROM `dr_users` WHERE disable_flag = '0' AND user_id= '$user_id' ";
        $RESULT_USER = mysqli_query($conn,$SELECT_USER);
        
        while ($ROW_USER = mysqli_fetch_assoc($RESULT_USER)) {
              $user_id = $ROW_USER['user_id'];  
            $first_name = $ROW_USER['first_name'];  
            $last_name = $ROW_USER['last_name']; 
           
            
            $post_username = $first_name." ".$last_name;
        }  
        
             $cmtDetails[]=array(
                                "comment_id" =>$comment_id,
                                "post_userid"=>$user_id ,
                                "post_id" => $post_id,
                                 "post_username"=>$post_username ,
                                "post_comment" => $post_comment,
                                "post_date" => $new_date
                               
                                );
        }

   $response=array("response"=> $cmtDetails);
       echo json_encode($response);

   
}else
    {
        $response=array("response"=> "failure");
        echo json_encode($response);
    }

?>
