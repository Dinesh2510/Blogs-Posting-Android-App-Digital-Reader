<?php
include 'connection.php';
        $post_id= null;
        $user_id = null; 




if($_SERVER['REQUEST_METHOD']=='POST'){

	$post_id = $_POST['post_id'];
	$user_id= $_POST['user_id'];

}

if($_SERVER['REQUEST_METHOD']=='GET'){


   $post_id = $_GET['post_id'];
    $user_id= $_GET['user_id'];
       
}
//Get the number of comments
$query_cmt = "SELECT *FROM dr_comments WHERE disable_flag='0' AND post_id='$post_id'"; 
$result_cmt = mysqli_query($conn, $query_cmt); 

 if ($result_cmt) 
    { 
        // it return number of rows in the table. 
        $row_cmt = mysqli_num_rows($result_cmt); 
    } 

//Get the number of Likes
$query = "SELECT *FROM dr_posts WHERE (disable_flag='0' OR disable_flag='2') AND post_id='$post_id'"; 
$result_select = mysqli_query($conn, $query); 
    
    while ($row=mysqli_fetch_array($result_select)) 
    { 
        $post_like = $row['post_like']; 
    } 
    
// $query_sel = "SELECT *FROM dr_posts WHERE disable_flag='0'   AND post_userid='$user_id'"; 
// $result = mysqli_query($conn, $query); 
    
//     if ($result) 
//     { 
//         $row_post = mysqli_num_rows($result); 
//     }     
    
    
$sql= "SELECT * FROM `dr_bookmark` WHERE `post_id`='$post_id' AND `user_id`='$user_id'AND `disable_flag`= '0'";
      $result=mysqli_query($conn,$sql);

if (mysqli_num_rows($result) > 0) {
    
     $Details=array(
                        
                      "post_like" =>$post_like, 
                      "post_comment"=>(string) $row_cmt);
    
	$result =array();
    $result["response"] ="success";
    $result["msg"] = $Details;
    echo json_encode($result);

	}

else
    {
        
        $Details=array(
                        // "post_count"=>$row_post,
                      "post_like" =>$post_like, 
                      "post_comment"=>(string) $row_cmt);
    $result =array();
    $result["response"] ="failure";
     $result["msg"] = $Details;
    echo json_encode($result);
    }

?>
