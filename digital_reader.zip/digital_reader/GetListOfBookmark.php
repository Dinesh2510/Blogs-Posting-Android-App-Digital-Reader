<?php

include "connection.php";



if($_SERVER['REQUEST_METHOD']=='POST'){

    $user_id = $_POST['user_id'];
  

}

if($_SERVER['REQUEST_METHOD']=='GET'){


   $user_id = $_GET['user_id'];
    
       
}  $sql_select="SELECT * FROM `dr_bookmark` WHERE `user_id`='$user_id'  AND  `disable_flag`= '0' ";  

$result_select=mysqli_query($conn,$sql_select);

$result_count=mysqli_num_rows($result_select);

if($result_count>0)
{
    while($row=mysqli_fetch_array($result_select))
        {

            $post_id=$row['post_id'];

//ye 1st query jo bnaya 
// $sql_select_post ="SELECT dr_bookmark.post_id, dr_posts.post_id,dr_posts.post_title,dr_posts.post_sub_title,dr_posts.post_content,dr_posts.post_image,dr_posts.post_date,dr_users.first_name,dr_users.last_name FROM dr_users,dr_posts,dr_bookmark WHERE dr_users.user_id = dr_posts.post_userid AND dr_posts.post_id=dr_bookmark.post_id ";

//ye 2nd fir se banya 
            // let me check 

            // $sql_select_post = "SELECT b.*,p.*,u.*,t.* FROM dr_users u LEFT JOIN dr_bookmark b ON u.id = b.user_id 
            // LEFT JOIN dr_posts p ON b.user_id = p.post_userid ";//LEFT JOIN dr_users u b.post_id = p.post_id, dr_topics t ";


 $sql_select_post= "SELECT b.*,p.*,u.*,t.* FROM dr_users u INNER JOIN dr_bookmark b ON u.user_id = b.user_id INNER JOIN dr_posts p ON b.post_id = p.post_id INNER JOIN dr_topics t ON t.topic_id = p.topic_id WHERE b.disable_flag = 0";

// karu kya run 
$result_select_post=mysqli_query($conn,$sql_select_post);
$UserDetails = array(); // kya kiya naki ?array defined nai tha ..ek hi array 2 baar define hora tha  ye asa ok why 
// u r usign inner join wo null data aaya tha na beech me uske liye use kiya ...inner join tab use karte hai jab kuch common ho 2 table ke beech me ...left join se jo cheej match nai hoti wo bhi result me aajata hai..innser join wahi records deta hai jo dono tale me common rahega inner se sab data le skat hai na apn haa
// mere ko ye nai smaj form user tabel inner join book mark on ....w3 schools pe jaa aur padh uspe samjhega 
//ok dekta hu call kar kran hai hai na ????? bhut bda dout hai ...kar call ok 
 while($row=mysqli_fetch_array($result_select_post))  {

            $post_id=$row['post_id'];
            $post_title=$row['post_title'];
            $post_sub_title=$row['post_sub_title'];
            $post_content=$row['post_content'];
           $post_userid=$row['post_userid'];
            $post_image=$row['post_image'];
            $post_date=$row['post_date'];
           // $topic_id=$row['topic_id'];
            $post_username = $row['first_name'].' '.$row['last_name'];
            $topic_title = $row['topic_title'];
             $post_link=$row['post_link'];
             $post_view=$row['post_view'];
               $post_like=$row['post_like'];
            $premium_flag=$row['premium_flag'];

         
        
                     $UserDetails[]=array( // idhr pe 
                                        "post_id" =>$post_id,
                                "post_title"=>$post_title,
                                "post_sub_title" => $post_sub_title,
                                "post_content" => $post_content,
                                "post_username" => $post_username,
                                "post_image" => $post_image,
                                "post_date"=>$post_date,
                                "post_userid"=>$post_userid,
                                "topics"=>$topic_title,
                                 "post_link"=>$post_link,
                                 "post_view"=>$post_view,
                                 "post_like"=>$post_like,
                                "premium_flag"=>$premium_flag


                            );
        }

        
}

     
 

   $response=array("response"=> $UserDetails);
       echo json_encode($response);

   
}else
    {
        $response=array("response"=> "failure");
        echo json_encode($response);
    }

?>
