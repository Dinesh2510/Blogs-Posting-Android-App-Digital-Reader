<?php
require 'connection.php';
require "PHPMailer/PHPMailerAutoload.php";
if($_SERVER['REQUEST_METHOD']=='POST')
{
        $email=$_POST['email'];
        $name =$_POST['name'];

       
}

if($_SERVER['REQUEST_METHOD']=='GET')
{
   
        $email=$_GET['email'];
        $name=$_GET['name'];
              

   
}
if (!isset($email) && !isset($name)&& empty($email) && empty($name)) {
	$status = "failed";
	$response = "Something wents Wrong!";
	exit(json_encode(array("status" => $status, "response" => $response)));
}
 $activation = mt_rand(100000, 999999);
 
    $to   = $email;
    $from = 'digitalreader@pixeldev.in';
    $name = 'Digital Reader';
    $subject = 'PHPMailer 5.2 testing from PixelDev';
    $msg = 'This is mail about testing mailing using PHP.';
    $body= file_get_contents('email_temp.php'); 
    $body = str_replace('[[activation_code]]', $activation, $body);
    $from_name="Digital Reader";
        
        
    //  "SELECT count(*),created_on FROM useres_table group by DATE_FORMAT(created_on, "%m-%d-%Y")";
        
     //   https://www.w3schools.com/sql/trymysql.asp?filename=trysql_func_mysql_date_format2
            
        $mail = new PHPMailer();
        $mail->IsSMTP();
        $mail->SMTPAuth = true; 
 
        $mail->SMTPSecure = 'ssl'; 
        $mail->Host = 'mail.pixeldev.in';
        $mail->Port = '465';  
        $mail->Username = 'digitalreader@pixeldev.in';
        $mail->Password = 'Pixel@1234@';   
   
   //   $path = 'reseller.pdf';
   //   $mail->AddAttachment($path);
   
        $mail->IsHTML(true);
        $mail->From="digitalreader@pixeldev.in";
        $mail->FromName=$from_name;
        $mail->Sender=$from;
        $mail->AddReplyTo($from, $from_name);
        $mail->Subject = "Digital Reader App confirmation ";
        $mail->Body = $body;
        $mail->AddAddress($email);
        
          if ($mail->send()) {
            $status = "success";
            $response = "Email is sent!";

            $sql = "INSERT INTO `user_verification`( `email`, `name`, `activation_code`, `is_active`) VALUES ( '$email', 
        	'$name', '$activation','0' )";
        	$result=mysqli_query($conn,$sql);

        } else {
            $status = "failed";
            $response = "Something is wrong: <br><br>" . $mail->ErrorInfo;
        }

        exit(json_encode(array("status" => $status, "response" => $response)));

    
    

    
?>

