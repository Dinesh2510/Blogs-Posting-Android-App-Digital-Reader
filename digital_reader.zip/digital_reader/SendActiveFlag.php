<?php
include 'connection.php';
       
        $email = null; 
        $password = null;



if($_SERVER['REQUEST_METHOD']=='POST'){

   
    $email= $_POST['email'];

}

if($_SERVER['REQUEST_METHOD']=='GET'){

  

    $email= $_GET['email'];

}
$sql_v="UPDATE user_verification SET `is_active`='0'  WHERE (`email`='$email')";
      $result_v=mysqli_query($conn,$sql_v);
$sql="UPDATE dr_users SET `active_flag`='0'  WHERE (`email`='$email')";
      $result=mysqli_query($conn,$sql);


if($result)
    {

    $response = array("response"=> "success");
      echo json_encode($response);
   


    }
else
    {
    $response = array("response"=>"failure");
    echo json_encode($response);
    }

?>
