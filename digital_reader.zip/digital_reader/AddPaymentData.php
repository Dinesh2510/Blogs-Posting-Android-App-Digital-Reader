<?php
include 'connection.php';
        $post_id= null;
        $user_id = null; 




if($_SERVER['REQUEST_METHOD']=='POST'){

	$razorpay_id = $_POST['razorpay_id'];
	$user_id= $_POST['user_id'];
	$txn_id= $_POST['txn_id'];
	$expiry_date= $_POST['expiry_date'];

}

if($_SERVER['REQUEST_METHOD']=='GET'){

    $razorpay_id = $_GET['razorpay_id'];
	$user_id= $_GET['user_id'];
	$txn_id= $_GET['txn_id'];
	$expiry_date= $_GET['expiry_date'];
	
  
       
}



$sql= "INSERT INTO `dr_payment`( `razorpay_id`, `user_id`, `txn_id`, `expiry_date`) VALUES (
		'$razorpay_id', 
        '$user_id',
        '$txn_id',
        '$expiry_date'
        )";


      $result=mysqli_query($conn,$sql);

if($result)
    {
    
    
$sql_select="UPDATE `dr_users` SET `user_premiumflag` = '1' WHERE `dr_users`.`user_id` = $user_id;";
$result_select=mysqli_query($conn,$sql_select);

	$sql_select="SELECT * FROM `dr_users` WHERE `user_id`='$user_id'";
	$result_select=mysqli_query($conn,$sql_select);



	        while($row=mysqli_fetch_assoc($result_select)) {
	         
	             $user_premiumflag=$row['user_premiumflag'];
	          }

	   $result_array[] = array("user_premiumflag" =>$user_premiumflag);
    
    $response = array("response"=>$result_array);
    	echo json_encode($response);
    }
else
    {
    	$response = array("response"=>"failure");
    	echo json_encode($response);
    }

?>
