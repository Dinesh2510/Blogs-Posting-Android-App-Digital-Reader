<?php

include "connection.php";



   
 $sql_select="SELECT * FROM `dr_cost`  WHERE  `disable_flag`= '0'";  
$result_select=mysqli_query($conn,$sql_select);

$result_count=mysqli_num_rows($result_select);

if($result_count>0)
{
    while($row=mysqli_fetch_array($result_select))
        {

            $price_id=$row['price_id'];
            $price=$row['price'];
        
             $CostDetails[]=array(
                                "price_id" =>$price_id,
                                "price"=>$price
                               
                                );
        }

   $response=array("response"=> $CostDetails);
       echo json_encode($response);

   
}else
    {
        $response=array("response"=> "failure");
        echo json_encode($response);
    }

?>
