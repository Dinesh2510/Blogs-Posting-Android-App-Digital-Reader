
<?php 
require_once('connection.php');
if($_SERVER['REQUEST_METHOD']=='POST'){
    $search_key= $_POST['search_key'];
}

if($_SERVER['REQUEST_METHOD']=='GET'){
    $search_key= $_GET['search_key'];      
}
if (!empty($search_key)) { 
    $columns = array();
    $res=mysqli_query($conn,"SHOW COLUMNS FROM dr_posts");
    while ($x = mysqli_fetch_assoc($res)){
      $columns[] = $x['Field'];
    }
    $GetData="SELECT * FROM `dr_posts` WHERE ";
    $where = array();
    foreach ($columns as $key => $value) {
      $where[] = $value.' LIKE "%'.$search_key.'%" ';
    }
    $GetData .= implode(' OR ', $where);
    $resultData=mysqli_query($conn,$GetData);//mla failur ala phije hota wait

    if($resultData){
        $PostDetails = array();
        //teko array me data chaiye tha to array declare karegana pele ...bina array declare karega to wo variable banta hai aur last assigned value ko save karta hai wo ha smaj abhi good
        $i=0;
        $search_results = array();
        while ($row= mysqli_fetch_assoc($resultData)){
            $search_results[$i]['post_id'] = $row['post_id'];
            $search_results[$i]['post_title'] = $row['post_title'];
            $search_results[$i]['post_content'] = $row['post_content'];
            $search_results[$i]['post_image'] = $row['post_image'];
            $search_results[$i]['post_date'] = $row['post_date'];
            $search_results[$i]['topic_id'] = $row['topic_id'];
            $search_results[$i]['post_link'] = $row['post_link'];
            $search_results[$i]['post_userid'] = $row['post_userid'];
            $search_results[$i]['post_sub_title'] = $row['post_sub_title'];
            $search_results[$i]['premium_flag'] = $row['premium_flag'];
            $search_results[$i]['post_view'] = $row['post_view'];
            $search_results[$i]['post_like'] = $row['post_like'];
                         $i++;

        

        $str_topicId = $row['topic_id'];
$SELECT_TOPIC = "SELECT * FROM `dr_topics` WHERE disable_flag = '0' AND topic_id= '$str_topicId' ";
        $RESULT_USER = mysqli_query($conn,$SELECT_TOPIC);
        
        while ($ROW_TOPIC = mysqli_fetch_assoc($RESULT_USER)) {
            
            $topic_id = $ROW_TOPIC['topic_id'];  
            $topics = $ROW_TOPIC['topic_title']; 
           
            
        }          
$str_userId=$row['post_userid'];
 $SELECT_USER = "SELECT * FROM `dr_users` WHERE disable_flag = '0' AND user_id= '$str_userId' ";
        $RESULT_USER = mysqli_query($conn,$SELECT_USER);
        
        while ($ROW_USER = mysqli_fetch_assoc($RESULT_USER)) {
            
            $first_name = $ROW_USER['first_name'];  
            $last_name = $ROW_USER['last_name']; 
           
            
            $post_username = $first_name." ".$last_name; //great bc kya error smja zara tune
        }


             $PostDetails[]=array(
                                "post_id" => $row['post_id'],
                                "post_title"=>$row['post_title'],
                                "post_content" => $row['post_content'],
                                "post_username" => $post_username,
                                "post_image" => $row['post_image'],
                                "post_date"=>$row['post_date'],
                                "post_link"=>$row['post_link'],
                                "post_userid"=>$row['post_userid'],
                                "post_sub_title"=>$row['post_sub_title'],
                                "premium_flag"=>$row['premium_flag'],
                                "post_view"=>$row['post_view'],
                                "post_like"=>$row['post_like'],
                                 "topics"=>$topics
                                );

       }
    }
    if($resultData->num_rows > 0 ){
        $response['status'] = true;
        $response['message'] = $PostDetails;
    } else {
        $response['status'] = false;
        $response['message'] = 'Oops...Something went wrong.Please try again.';
    } 
    die(json_encode($response));
}

?>


