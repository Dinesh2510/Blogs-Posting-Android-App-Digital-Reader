<?php
include 'connection.php';

        $topic_id= null;
        $user_id= null;
      

if($_SERVER['REQUEST_METHOD']=='POST'){

	$topic_id = $_POST['topic_id'];
	$user_id= $_POST['user_id'];
    
	
}

if($_SERVER['REQUEST_METHOD']=='GET'){


   $topic_id = $_GET['topic_id'];
    $user_id= $_GET['user_id'];
    
       
}



$sql= "UPDATE dr_following SET disable_flag = '1' WHERE user_id = $user_id AND topic_id=$topic_id;";



      $result=mysqli_query($conn,$sql);

if($result)
    {
    
    $response = array("response"=>"success");
    	echo json_encode($response);
    }
else
    {
    	$response = array("response"=>"failure");
    	echo json_encode($response);
    }

?>
