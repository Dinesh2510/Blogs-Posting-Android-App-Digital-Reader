<?php
include 'connection.php';
        $post_id= null;
        $user_id = null; 




if($_SERVER['REQUEST_METHOD']=='POST'){

	$post_id = $_POST['post_id'];
	$user_id= $_POST['user_id'];

}

if($_SERVER['REQUEST_METHOD']=='GET'){


   $post_id = $_GET['post_id'];
    $user_id= $_GET['user_id'];
       
}



$sql= "INSERT INTO `dr_bookmark`( `post_id`, `user_id`) VALUES (
		'$post_id', 
        '$user_id'
        
        
)";


      $result=mysqli_query($conn,$sql);

if($result)
    {
    
    $response = array("response"=>"success");
    	echo json_encode($response);
    }
else
    {
    	$response = array("response"=>"failure");
    	echo json_encode($response);
    }

?>
