<?php

include "connection.php";

$name = null;
$email=null;
$phone=null;
$address=null;
$password=null;
$user_id=null;


if($_SERVER['REQUEST_METHOD']=='POST')
{
        $user_id=$_POST['user_id'];

       
}


if($_SERVER['REQUEST_METHOD']=='GET')
{
   
        $user_id=$_GET['user_id'];
       
   
}

$query_follow = "SELECT *FROM dr_following WHERE disable_flag='0' AND user_id='$user_id'"; 
$result_follow = mysqli_query($conn, $query_follow); 

 if ($result_follow) 
    { 
        // it return number of rows in the table. 
        $row_follow = mysqli_num_rows($result_follow); 
    } 


$query = "SELECT *FROM dr_posts WHERE disable_flag='0' AND post_userid='$user_id'"; 
$result = mysqli_query($conn, $query); 
    
    if ($result) 
    { 
        $row_post = mysqli_num_rows($result); 
    } 
   
$query_bk = "SELECT *FROM dr_bookmark WHERE disable_flag='0' AND user_id='$user_id' " ; 
$result_bk = mysqli_query($conn, $query_bk); 
    
    if ($result_bk) 
    { 
        $row_bk = mysqli_num_rows($result_bk); 
    } 

$sql_select="SELECT * FROM `dr_users` WHERE `user_id`='$user_id' ";
$result_select=mysqli_query($conn,$sql_select);

$result_count=mysqli_num_rows($result_select);

if($result_count>0)
{
    while($row=mysqli_fetch_array($result_select))
        {
            
             $user_id=$row['user_id'];
           
  
             $UserDetails=array(
                "user_id" =>$user_id,
                                "row_post" =>$row_post,
                                 "row_follow" =>$row_follow,
                                "row_bk" => $row_bk
                            
                                );
     

        }

   
   
}

    if($result_count)
    {          
       $response=array("response"=> $UserDetails);
       echo json_encode($response);
       
    }else
    {
        $response=array("response"=> "failure");
        echo json_encode($response);
    }

   


?>