<?php
include 'connection.php';
        $post_id= null;
        $user_id = null; 




if($_SERVER['REQUEST_METHOD']=='POST'){

    $post_id = $_POST['post_id'];
    $user_id= $_POST['user_id'];

}

if($_SERVER['REQUEST_METHOD']=='GET'){


   $post_id = $_GET['post_id'];
    $user_id= $_GET['user_id'];
       
}


$sql= "UPDATE dr_bookmark SET `disable_flag`= '1' WHERE user_id = $user_id AND post_id=$post_id;";


      $result=mysqli_query($conn,$sql);

if($result)
    {
    
    $response = array("response"=>"success");
        echo json_encode($response);
    }
else
    {
        $response = array("response"=>"failure");
        echo json_encode($response);
    }

?>
