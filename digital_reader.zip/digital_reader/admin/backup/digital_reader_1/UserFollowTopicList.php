<?php

include "connection.php";

if($_SERVER['REQUEST_METHOD']=='POST'){

    $user_id = $_POST['user_id'];
    

    

}

if($_SERVER['REQUEST_METHOD']=='GET'){


   $user_id = $_GET['user_id'];
    
       
}


   
 $sql_select="SELECT * FROM `dr_following`  WHERE `user_id`= '$user_id' AND `disable_flag`= '0' ORDER BY 'following_id' DESC";  
$result_select=mysqli_query($conn,$sql_select);

$result_count=mysqli_num_rows($result_select);

if($result_count>0)
{
    while($row=mysqli_fetch_array($result_select))
        {



            $following_id=$row['following_id'];
            $user_id=$row['user_id'];
            $topic_id=$row['topic_id'];

           
        $SELECT_TOPIC = "SELECT * FROM `dr_topics` WHERE disable_flag = '0' AND topic_id= '$topic_id' ";
        $RESULT_USER = mysqli_query($conn,$SELECT_TOPIC);
        
        while ($ROW_TOPIC = mysqli_fetch_assoc($RESULT_USER)) {
            
            $topic_id = $ROW_TOPIC['topic_id'];  
            $topic_title = $ROW_TOPIC['topic_title']; 
            $topic_image = $ROW_TOPIC['topic_image'];
           
            
        }    
     

 $TopicDetails[]=array(
                        "topic_id" =>$topic_id,
                       "topic_title"=>$topic_title,
                       "topic_image" => $topic_image,
                               
                                );


        

}

   $response=array("response"=> $TopicDetails);
       echo json_encode($response);

   
}else
    {
        $response=array("response"=> "failure");
        echo json_encode($response);
    }

?>
