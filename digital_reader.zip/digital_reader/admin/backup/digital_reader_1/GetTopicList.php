<?php

include "connection.php";



   
 $sql_select="SELECT * FROM `dr_topics`  WHERE  `disable_flag`= '0' ORDER BY topic_id DESC";  
$result_select=mysqli_query($conn,$sql_select);

$result_count=mysqli_num_rows($result_select);

if($result_count>0)
{
    while($row=mysqli_fetch_array($result_select))
        {

            $topic_id=$row['topic_id'];
            $topic_title=$row['topic_title'];
            $topic_image=$row['topic_image'];
        
             $PostDetails[]=array(
                                "topic_id" =>$topic_id,
                                "topic_title"=>$topic_title,
                                "topic_image" => $topic_image,
                               
                                );
        }

   $response=array("response"=> $PostDetails);
       echo json_encode($response);

   
}else
    {
        $response=array("response"=> "failure");
        echo json_encode($response);
    }

?>
