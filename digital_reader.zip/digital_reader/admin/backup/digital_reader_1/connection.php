<?php



$servername = "localhost";
$username = "hyqgektr_digitalreader";
$password = "BSRp,Tg1,Nuo";
$dbname = "hyqgektr_digital_reader";

$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
date_default_timezone_set("Asia/Kolkata");
mysqli_set_charset($conn, "utf8");
?>