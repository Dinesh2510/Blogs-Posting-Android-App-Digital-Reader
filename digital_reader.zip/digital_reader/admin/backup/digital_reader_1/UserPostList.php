<?php

include "connection.php";


if($_SERVER['REQUEST_METHOD']=='POST'){

   $user_id = $_POST['user_id'];
   

}

if($_SERVER['REQUEST_METHOD']=='GET'){

    $user_id = $_GET['user_id'];
   
   
}

   
 $sql_select="SELECT * FROM `dr_posts`  WHERE  `post_userid`= '$user_id' AND `disable_flag`= '0' ORDER BY post_id DESC";  
$result_select=mysqli_query($conn,$sql_select);

$result_count=mysqli_num_rows($result_select);

if($result_count>0)
{
    while($row=mysqli_fetch_array($result_select))
        {



            $post_id=$row['post_id'];
            $post_title=$row['post_title'];
            $post_sub_title=$row['post_sub_title'];
            $post_content=$row['post_content'];
            $post_userid=$row['post_userid'];
            $post_image=$row['post_image'];
            $post_date=$row['post_date'];
            $topic_id=$row['topic_id'];
           


 $SELECT_TOPIC = "SELECT * FROM `dr_topics` WHERE disable_flag = '0' AND topic_id= '$topic_id' ";
        $RESULT_USER = mysqli_query($conn,$SELECT_TOPIC);
        
        while ($ROW_TOPIC = mysqli_fetch_assoc($RESULT_USER)) {
            
            $topic_id = $ROW_TOPIC['topic_id'];  
            $topics = $ROW_TOPIC['topic_title']; 
           
            
        }          

 $SELECT_USER = "SELECT * FROM `dr_users` WHERE disable_flag = '0' AND user_id= '$post_userid' ";
        $RESULT_USER = mysqli_query($conn,$SELECT_USER);
        
        while ($ROW_USER = mysqli_fetch_assoc($RESULT_USER)) {
            
            $first_name = $ROW_USER['first_name'];  
            $last_name = $ROW_USER['last_name']; 
           
            
            $post_username = $first_name." ".$last_name;
        }




 
$new_date = date("d-F-Y",strtotime($post_date));

             $PostDetails[]=array(
                                "post_id" =>$post_id,
                                "post_title"=>$post_title,
                                "post_sub_title" => $post_sub_title,
                                "post_content" => $post_content,
                                "post_username" => $post_username,
                                "post_image" => $post_image,
                                "post_date"=>$new_date,
                                 "topics"=>$topics
                                );
     


        }



   $response=array("response"=> $PostDetails);
       echo json_encode($response);

   
}else
    {
        $response=array("response"=> "failure");
        echo json_encode($response);
    }

?>
