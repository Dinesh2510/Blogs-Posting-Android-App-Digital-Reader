<?php

include "connection.php";

$new_text=null;

if($_SERVER['REQUEST_METHOD']=='POST'){

    $user_id = $_POST['user_id'];
    

    

}

if($_SERVER['REQUEST_METHOD']=='GET'){


   $user_id = $_GET['user_id'];
    
       
}


   
 $sql_select="SELECT * FROM `dr_following`  WHERE `user_id`= '$user_id' AND `disable_flag`= '0' ORDER BY 'following_id' DESC";  
$result_select=mysqli_query($conn,$sql_select);

$result_count=mysqli_num_rows($result_select);

if($result_count>0)
{
    while($row=mysqli_fetch_array($result_select))
        {



            $following_id=$row['following_id'];
            $user_id=$row['user_id'];
            $topic_id=$row['topic_id'];
             $disable_flag=$row['disable_flag'];
           


if ($disable_flag == "0") {
    $new_text ="Following";

}else{
        $new_text ="Follow";
}


           
             $PostDetails[]=array(
                                "topic_id" => $topic_id ,
                                "new_text"=> $new_text 
                                 );
     


        }



   $response=array("response"=> $PostDetails);
       echo json_encode($response);

   
}else
    {
        $response=array("response"=> "failure");
        echo json_encode($response);
    }

?>
