<?php

include "connection.php";


if($_SERVER['REQUEST_METHOD']=='POST'){

   $email = $_POST['email'];
   $code = $_POST['code'];
   

}

if($_SERVER['REQUEST_METHOD']=='GET'){

    $email = $_GET['email'];
    $code = $_GET['code'];
   
   
}


$sql_check_email ="SELECT * FROM `dr_users` WHERE `email`= '$email' ";
$result_chk_email=mysqli_query($conn,$sql_check_email);
if($result_chk_email->num_rows >= 1) {
    $email_result = true;  
}else{  
    $email_result = false;
}



$sql_select="SELECT * FROM `user_verification` WHERE `email`= '$email' AND `activation_code`= '$code' AND `disable_flag`= '0'";  
$result=mysqli_query($conn,$sql_select);
$result_count=mysqli_num_rows($result);


if($email_result == true && $result_count > 0 ){
$update_flag = "UPDATE `dr_users` SET `active_flag` = '0' WHERE `email` = '$email'";
$result_flag =mysqli_query($conn,$update_flag);

$result =array();
$result["msg"] ="success";
$result["response"] = "Email is Verified";
echo json_encode($result);
}else if($email_result == false ){
    $result =array();
    $result["msg"] ="failure";
    $result["response"] ="Email is not Registred";
    echo json_encode($result);
}else if($result_count == 0){
  
    $result =array();
    $result["msg"] ="failure";
    $result["response"] ="code is not match";
    echo json_encode($result);

}

/*var_dump($result_count);
die;*/

/*if($result)
{
 
    $result =array();
    $result["msg"] ="success";
    $result["response"] = "Email is Verified";
    echo json_encode($result);
}else
    {
    $result =array();
    $result["msg"] ="failure";
    $result["response"] ="Something wents Wrong!";
    echo json_encode($result);
    }
*/


?>
