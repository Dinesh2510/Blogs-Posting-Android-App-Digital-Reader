<?php
include 'connection.php';

        $topic_id= null;
        $user_id= null;
      

if($_SERVER['REQUEST_METHOD']=='POST'){

	$topic_id = $_POST['topic_id'];
	$user_id= $_POST['user_id'];
    
	
}

if($_SERVER['REQUEST_METHOD']=='GET'){


   $topic_id = $_GET['topic_id'];
    $user_id= $_GET['user_id'];
    
       
}



$sql= "INSERT INTO `dr_following`( `user_id`, `topic_id`) VALUES (
		'$user_id', 
        '$topic_id'
        )";


      $result=mysqli_query($conn,$sql);

if($result)
    {
    
    $response = array("response"=>"success");
    	echo json_encode($response);
    }
else
    {
    	$response = array("response"=>"failure");
    	echo json_encode($response);
    }

?>
