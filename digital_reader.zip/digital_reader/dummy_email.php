<?php
 require_once('connection.php');
 require "PHPMailer/PHPMailerAutoload.php";

        //Genrate Random Number for activation and store
        $activation = uniqid(rand(),true);
        $email='dineshchavan2510@gmail.com';
        $first_name ='Dinesh';
        $user_id= '55';
            

        // use PHPMailer\PHPMailer\PHPMailer;
        // use PHPMailer\PHPMailer\Exception;
        
        // require_once "PHPMailer/PHPMailer.php";
        // require_once "PHPMailer/SMTP.php";
        // require_once "PHPMailer/Exception.php";
        //require 'vendor/autoload.php';


        $mail = new PHPMailer();

        //SMTP Settings
        $mail->isSMTP();
        $mail->Host = "mail.pixeldev.in";
        $mail->SMTPAuth = true;
        $mail->Username = "digitalreader@pixeldev.in";
        $mail->Password = 'Pixel@1234@';
        $mail->Port = 465; //587,465
        $mail->SMTPSecure = "tls"; //ssl



        //Email Settings
        $mail->isHTML(true);
        $mail->setFrom("digitalreader@pixeldev.in","Digital Reader");
        $mail->addAddress($email);
       $mail->Subject = "<h1>Registration Confirmation</h1>";
        $mail->Body = "<p>Hello,$first_name  </p>
            <p>Thank you for registering at Digi Blogs.</p>
            <p>To activate your account, please click on this link:<a href='http://localhost/blog/blog_2/activation_code.php?active=$activation&&user_id=$user_id'>http://localhost/blog/blog_2/activation_code.php?active=$activation&&user_id=$user_id</a>
           </p>
            <p>Regards Site Admin</p>";

 
        if ($mail->send()) {
            $status = "success";
            $response = "Email is sent!";
        } else {
            $status = "failed";
            $response = "Something is wrong: <br><br>" . $mail->ErrorInfo;
        }

        exit(json_encode(array("status" => $status, "response" => $response)));
    
?>
