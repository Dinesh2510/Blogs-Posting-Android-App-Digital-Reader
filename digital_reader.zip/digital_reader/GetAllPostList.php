<?php

include "connection.php";

if($_SERVER['REQUEST_METHOD']=='POST'){
    	$limit = $_POST['limit'];

    
}

if($_SERVER['REQUEST_METHOD']=='GET'){
       $limit = $_GET['limit'];

}


if($limit == "0"){
$sql_select="SELECT * FROM `dr_posts`  WHERE  `disable_flag`= '0' LIMIT 5";  
$result_select=mysqli_query($conn,$sql_select);
}else{
$sql_select="SELECT * FROM `dr_posts`  WHERE  `disable_flag`= '0'";  
$result_select=mysqli_query($conn,$sql_select); 
}

$result_count=mysqli_num_rows($result_select);
if($result_count>0)
{
    while($row=mysqli_fetch_array($result_select))
        {



            $post_id=$row['post_id'];
            $post_title=$row['post_title'];
            $post_sub_title=$row['post_sub_title'];
            $post_content=$row['post_content'];
            $post_userid=$row['post_userid'];
            $post_image=$row['post_image'];
            $post_date=$row['post_date'];
            $topic_id=$row['topic_id'];
            $post_link=$row['post_link'];
            $post_view=$row['post_view'];
            $post_like=$row['post_like'];
            $premium_flag=$row['premium_flag'];

           


 $SELECT_TOPIC = "SELECT * FROM `dr_topics` WHERE disable_flag = '0' AND topic_id= '$topic_id' ";
        $RESULT_USER = mysqli_query($conn,$SELECT_TOPIC);
        
        while ($ROW_TOPIC = mysqli_fetch_assoc($RESULT_USER)) {
            
            $topic_id = $ROW_TOPIC['topic_id'];  
            $topics = $ROW_TOPIC['topic_title']; 
           
            
        }          
if($post_userid == "0"){
    $post_username="Admin";
}else{
   $SELECT_USER = "SELECT * FROM `dr_users` WHERE disable_flag = '0' AND user_id= '$post_userid' ";
        $RESULT_USER = mysqli_query($conn,$SELECT_USER);
        
        while ($ROW_USER = mysqli_fetch_assoc($RESULT_USER)) {
              $user_id = $ROW_USER['user_id'];  
            $first_name = $ROW_USER['first_name'];  
            $last_name = $ROW_USER['last_name']; 
           
            
            $post_username = $first_name." ".$last_name;
        }  
}





 
$new_date = date("d-F-Y",strtotime($post_date));

             $PostDetails[]=array(
                               "post_id" =>$post_id,
                                "post_title"=>$post_title,
                                "post_sub_title" => $post_sub_title,
                                "post_content" => $post_content,
                                "post_userid"=>$post_userid,
                                "post_username" => $post_username,
                                "post_image" => $post_image,
                                "post_date"=>$new_date,
                                "post_link"=>$post_link,
                                 "topics"=>$topics,
                                 "post_view"=>$post_view,
                                 "post_like"=>$post_like,
                                "premium_flag"=>$premium_flag

                                );
     


        }



   $response=array("response"=> $PostDetails);
       echo json_encode($response);

   
}else
    {
        $response=array("response"=> "failure");
        echo json_encode($response);
    }

?>
