<?php

include "connection.php";



   
 $sql_select="SELECT * FROM `dr_appinfo`  WHERE  `disable_flag`= '0'";  
$result_select=mysqli_query($conn,$sql_select);

$result_count=mysqli_num_rows($result_select);

if($result_count>0)
{
    while($row=mysqli_fetch_array($result_select))
        {

            $app_id=$row['app_id'];
            $app_version=$row['app_version'];
            $app_code=$row['app_code'];
        
             $Details=array(
                                "app_id" =>$app_id,
                                "app_version" =>$app_version,
                                "app_code"=>$app_code
                               
                                );
        }

   $response=array("response"=> $Details);
       echo json_encode($response);

   
}else
    {
        $response=array("response"=> "failure");
        echo json_encode($response);
    }

?>
