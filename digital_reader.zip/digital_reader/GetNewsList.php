<?php

include "connection.php";




 $sql_select="SELECT * FROM `dr_news`  WHERE  `disable_flag`= '0'";  
$result_select=mysqli_query($conn,$sql_select);

$result_count=mysqli_num_rows($result_select);
if($result_count>0)
{
    while($row=mysqli_fetch_array($result_select))
        {



            $news_id=$row['news_id'];
            $news_title=$row['news_title'];
            $news_detail=$row['news_detail'];
            $news_image=$row['news_image'];
            $news_date=$row['news_date'];
            $news_userid=$row['news_userid'];
          

           
if($news_userid == "0"){
    $news_username="Admin";
}else{
   $SELECT_USER = "SELECT * FROM `dr_users` WHERE disable_flag = '0' AND user_id= '$news_userid' ";
        $RESULT_USER = mysqli_query($conn,$SELECT_USER);
        
        while ($ROW_USER = mysqli_fetch_assoc($RESULT_USER)) {
              $user_id = $ROW_USER['user_id'];  
            $first_name = $ROW_USER['first_name'];  
            $last_name = $ROW_USER['last_name']; 
           
            
            $news_username = $first_name." ".$last_name;
        }  
}





 
$new_date = date("d-F-Y",strtotime($news_date));

             $NewsDetails[]=array(
                               "news_id" =>$news_id,
                                "news_title"=>$news_title,
                                "news_detail" => $news_detail,
                                "news_date" => $new_date,
                                "news_userid"=>$news_userid,
                                "news_username" => $news_username,
                                "news_image" => $news_image
                                

                                );
     


        }



   $response=array("response"=> $NewsDetails);
       echo json_encode($response);

   
}else
    {
        $response=array("response"=> "failure");
        echo json_encode($response);
    }

?>
